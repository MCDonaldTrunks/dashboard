Possible dashboard items:
- books read.
- vocabulary.
- miles ran.
- balance sheet.
- cripto/asset price tracker.
- to do list/ planner.
- image manager.


Sidebar Items:
- readings.
- account.
- settings.
- pictures.
- health.

Health:
- exercise.
- training.
- running 
- Nutrition records.
- Food Library.
- 
- 

readings
- books
- articles
- other 