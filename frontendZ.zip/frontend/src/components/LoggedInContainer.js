import React from "react";
import { Route, Routes } from "react-router-dom";
import MySidebar from "./MySidebar";
import Dashboard from "../pages/Dashboard/Dashboard";
import Calendar from "../pages/Calendar/Calendar";
import Readings from "../pages/Readings/Readings";
import Health from "../pages/Health/Health";
import Financials from "../pages/Financials/Financials";
import ProtectedRoute from "./ProtectedRoute";
import styled from "styled-components";

// Define the styled components for the layout
const Container = styled.div`
  display: flex;
  align-items: stretch;
  width: 100%;
  height: 100vh;
`;

const MainContent = styled.div`
  background-color: #15215d;
  flex-grow: 1;
  padding: 20px;
  overflow-y: auto; // Allow scrolling for longer content
`;

const LoggedInContainer = () => {
  console.log("Rendering LoggedInContainer"); // Debug re-render

  return (
    <Container>
      <MySidebar />
      <MainContent>
        <Routes>
          {/* Define all protected routes here */}
          <Route
            path="/"
            element={
              <ProtectedRoute>
                <Dashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/calendar"
            element={
              <ProtectedRoute>
                <Calendar />
              </ProtectedRoute>
            }
          />
          <Route
            path="/readings"
            element={
              <ProtectedRoute>
                <Readings />
              </ProtectedRoute>
            }
          />
          <Route
            path="/health"
            element={
              <ProtectedRoute>
                <Health />
              </ProtectedRoute>
            }
          />
          <Route
            path="/financials"
            element={
              <ProtectedRoute>
                <Financials />
              </ProtectedRoute>
            }
          />
        </Routes>
      </MainContent>
    </Container>
  );
};

export default LoggedInContainer;
