import React from 'react'

function Pictures() {
  return (
    <div>Pictures</div>
  )
}

export default Pictures