import React from 'react'

function Health() {
  return (
    <div>Health</div>
  )
}

export default Health