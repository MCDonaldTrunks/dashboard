import React from 'react'

function Financials() {
  return (
    <div>Financials</div>
  )
}

export default Financials