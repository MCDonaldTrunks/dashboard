import React from 'react'

function Journal() {
  return (
    <div>Journal</div>
  )
}

export default Journal