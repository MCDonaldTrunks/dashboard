import React from 'react'

function Readings() {
  return (
    <div>Readings</div>
  )
}

export default Readings