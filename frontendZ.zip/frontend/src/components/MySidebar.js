import React, { useState, useEffect } from "react";
import { Sidebar, Menu, MenuItem, SubMenu } from "react-pro-sidebar";
import { Link, useLocation } from "react-router-dom";
import styled from "styled-components";
import logout from "./login/logout";

// ****Icons****
import MenuIcon from "@mui/icons-material/Menu";
import ImportContactsIcon from "@mui/icons-material/ImportContacts";
import EventIcon from "@mui/icons-material/Event";
import PhotoSizeSelectActualIcon from "@mui/icons-material/PhotoSizeSelectActual";
import FavoriteIcon from "@mui/icons-material/Favorite";
import SettingsIcon from "@mui/icons-material/Settings";
import DashboardIcon from "@mui/icons-material/Dashboard";
import CheckBoxIcon from "@mui/icons-material/CheckBox";
import AttachMoneyIcon from "@mui/icons-material/AttachMoney";
import CreateIcon from "@mui/icons-material/Create";
import LogoutIcon from '@mui/icons-material/Logout';

// Define the styled components for the sidebar
const StyledSidebar = styled(Sidebar)`
  position: relative;
  color: #fff;
  height: 100%;
  z-index: 0;
  ::-webkit-scrollbar {
    width: 5px;
  }
  ::-webkit-scrollbar-thumb {
    background: rgba(153, 153, 153, 0.27);
    border-radius: 10px;
  }
  ::-webkit-scrollbar-thumb:hover {
    background: #555;
  }
`;

const MenuIconBox = styled.div`
  display: flex;
  height: 150px;
  width: 100%;
  justify-content: center;
  align-items: center;
`;

const StyledMenu = styled(Menu)`
  li:not(.sub) {
    margin-top: 30px;
  }
`;

const StyledMenuItem = styled(MenuItem)``;

const LogOutButton = styled(MenuItem)`
  color: #d9534f;
  &:hover {
    background-color: #f2dede;
  }
`;

const MySidebar = () => {
  const [collapsed, setCollapsed] = useState(true);
  const location = useLocation();
  const [active, setActive] = useState("dashboard");

  // On initial load, set the active category from local storage
  useEffect(() => {
    const storedActiveCategory = localStorage.getItem("activeCategory");
    if (storedActiveCategory) {
      setActive(storedActiveCategory);
    }
  }, []);

  const toggleSidebar = () => {
    setCollapsed(!collapsed);
  };

  // Set active menu item and store it in local storage
  const handleMenuItemClick = (category) => {
    setActive(category);
    localStorage.setItem("activeCategory", category);
  };

  // Sync the active menu item with the current URL path
  useEffect(() => {
    const pathname = location.pathname.toLowerCase();
    const category = getCategoryFromPath(pathname);
    if (category) {
      setActive(category);
    }
  }, [location.pathname]);

  // Map paths to categories
  const getCategoryFromPath = (pathname) => {
    const categoryMap = {
      "/": "dashboard",
      "/readings": "readings",
      "/calendar": "calendar",
      "/pictures": "pictures",
      "/health": "health",
      "/financials": "financials",
      "/todo": "todo",
      "/journal": "journal",
    };
    return categoryMap[pathname];
  };

  return (
    <StyledSidebar
      collapsed={collapsed}
      backgroundColor="#1C244B"
      style={{ border: "none", color: "#FBEAEB", fontFamily: "Roboto" }}
    >
      <MenuIconBox>
        <MenuIcon onClick={toggleSidebar} style={{ cursor: "pointer" }} />
      </MenuIconBox>
      <StyledMenu
        menuItemStyles={{
          button: ({ level, active, disabled }) => {
            if (level === 0) {
              return {
                color: disabled ? "pink" : "#D5D8E6",
                backgroundColor: active ? "#088001" : undefined,
                "&:hover": {
                  backgroundColor: active ? "#088001" : "#313F83",
                  color: "white !important",
                },
              };
            }
            if (level === 1) {
              return {
                color: disabled ? "#eee" : "#D5D8E6",
                backgroundColor: active ? "#fff" : "#1C244B",
                "&:hover": {
                  backgroundColor: active ? "red" : "#313F83",
                  color: "white !important",
                },
              };
            }
          },
        }}
        className="rps-sidebar"
      >
        {/* Set Up SubMenu */}
        <SubMenu
          className="sub"
          icon={<SettingsIcon />}
          label={collapsed ? "" : "Set up"}
        >
          <StyledMenuItem className="sub"> Settings </StyledMenuItem>
          <StyledMenuItem className="sub"> Account </StyledMenuItem>
        </SubMenu>

        {/* Individual Menu Items */}
        <StyledMenuItem
          onClick={() => handleMenuItemClick("dashboard")}
          active={active === "dashboard"}
          component={<Link to="/" />}
          icon={<DashboardIcon />}
        >
          {collapsed ? "" : <span>Dashboard</span>}
        </StyledMenuItem>
        <StyledMenuItem
          onClick={() => handleMenuItemClick("readings")}
          active={active === "readings"}
          component={<Link to="/readings" />}
          icon={<ImportContactsIcon />}
        >
          {collapsed ? "" : <span>Readings</span>}
        </StyledMenuItem>
        <StyledMenuItem
          onClick={() => handleMenuItemClick("calendar")}
          active={active === "calendar"}
          component={<Link to="/calendar" />}
          icon={<EventIcon />}
        >
          {collapsed ? "" : <span>Calendar</span>}
        </StyledMenuItem>
        <StyledMenuItem
          onClick={() => handleMenuItemClick("pictures")}
          active={active === "pictures"}
          component={<Link to="/pictures" />}
          icon={<PhotoSizeSelectActualIcon />}
        >
          {collapsed ? "" : <span>Pictures</span>}
        </StyledMenuItem>
        <StyledMenuItem
          onClick={() => handleMenuItemClick("health")}
          active={active === "health"}
          component={<Link to="/health" />}
          icon={<FavoriteIcon />}
        >
          {collapsed ? "" : <span>Health</span>}
        </StyledMenuItem>
        <StyledMenuItem
          onClick={() => handleMenuItemClick("financials")}
          active={active === "financials"}
          component={<Link to="/financials" />}
          icon={<AttachMoneyIcon />}
        >
          {collapsed ? "" : <span>Financials</span>}
        </StyledMenuItem>
        <StyledMenuItem
          onClick={() => handleMenuItemClick("todo")}
          active={active === "todo"}
          component={<Link to="/todo" />}
          icon={<CheckBoxIcon />}
        >
          {collapsed ? "" : <span>Todo</span>}
        </StyledMenuItem>
        <StyledMenuItem
          onClick={() => handleMenuItemClick("journal")}
          active={active === "journal"}
          component={<Link to="/journal" />}
          icon={<CreateIcon />}
        >
          {collapsed ? "" : <span>Journal</span>}
        </StyledMenuItem>

        {/* Log Out Button */}
        <LogOutButton
          icon={<LogoutIcon />}
          onClick={logout}
        >
          {collapsed ? "" : <span>Log Out</span>}
        </LogOutButton>
      </StyledMenu>
    </StyledSidebar>
  );
};

export default MySidebar;
