import React from 'react'
import styled from'styled-components'

function LandingPage() {
  return (
    <div>LandingPage</div>
  )
}

export default LandingPage