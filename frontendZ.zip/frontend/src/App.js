import React, { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import LoggedInContainer from "./components/LoggedInContainer";
import LoggedOutContainer from "./components/LoggedOutContainer";

function App() {
  // Set up state to track authentication
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  // Function to check if the token exists in localStorage
  const checkAuth = () => {
    const token = localStorage.getItem('access');
    return !!token;  // Returns true if token exists, false otherwise
  };

  // On component mount, check if the user is authenticated
  useEffect(() => {
    const authenticated = checkAuth();
    setIsAuthenticated(authenticated);

    if (!authenticated && location.pathname !== '/register' && location.pathname !== '/login') {
      // Redirect to login page only if trying to access protected paths while not logged in
      navigate('/login');
    } else if (authenticated) {
      // Redirect to home page or dashboard after login
      navigate('/');
    }

    // Set up listener to handle authentication state changes dynamically
    const handleStorageChange = () => {
      const newAuthState = checkAuth();
      setIsAuthenticated(newAuthState);
      if (newAuthState) {
        navigate('/');
      } else {
        navigate('/login');
      }
    };

    // Listen for local storage changes
    window.addEventListener('storage', handleStorageChange);

    // Clean up event listener on component unmount
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, [navigate, location]);

  return (
    <>
      {/* If user is authenticated, show the logged-in container, otherwise show the logged-out container */}
      {isAuthenticated ? <LoggedInContainer /> : <LoggedOutContainer />}
    </>
  );
}

export default App;
